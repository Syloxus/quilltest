const script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
script.setAttribute('src', 'https://syloxus.github.io/quilltest/quillbot.js');
document.head.appendChild(script);